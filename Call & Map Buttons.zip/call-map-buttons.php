<?php
/**
 * Plugin Name: Call & Map Buttons
 * Description: Adds call and map buttons on mobile, with customizable options from the admin panel.
 * Version: 1.5
 * Author: Liviu Moise
 * License: GPL2
 * Year: 2025
 */

// Add options to the admin menu
function call_map_buttons_menu() {
    add_options_page(
        'Call & Map Buttons Settings', // Title
        'Call & Map Buttons', // Menu title
        'manage_options',
        'call-map-buttons',
        'call_map_buttons_settings_page'
    );
}
add_action('admin_menu', 'call_map_buttons_menu');

// Sanitization functions
function sanitize_phone($input) {
    // Allow only valid characters for phone numbers
    $input = preg_replace('/[^0-9+]/', '', $input);
    return $input; // Without tel: prefix
}

function sanitize_address($input) {
    // Ensure it’s a valid URL
    return esc_url_raw($input);
}

function sanitize_button_text($input) {
    // Sanitize button text to prevent XSS
    return sanitize_text_field($input);
}

// Admin settings page
function call_map_buttons_settings_page() {
    ?>
    <div class="wrap">
        <h1>Call & Map Buttons Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('call_map_buttons_group');
            do_settings_sections('call-map-buttons');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Phone Number</th>
                    <td><input type="text" name="call_map_phone" value="<?php echo esc_attr(get_option('call_map_phone')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Map Link</th>
                    <td><input type="text" name="call_map_address" value="<?php echo esc_attr(get_option('call_map_address')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Call Button Text</th>
                    <td><input type="text" name="call_map_call_label" value="<?php echo esc_attr(get_option('call_map_call_label', 'CALL')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Map Button Text</th>
                    <td><input type="text" name="call_map_map_label" value="<?php echo esc_attr(get_option('call_map_map_label', 'MAP')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Call Button Background Color</th>
                    <td><input type="color" name="call_map_call_bg" value="<?php echo esc_attr(get_option('call_map_call_bg', '#28a745')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Call Button Text Color</th>
                    <td><input type="color" name="call_map_call_text" value="<?php echo esc_attr(get_option('call_map_call_text', '#ffffff')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Map Button Background Color</th>
                    <td><input type="color" name="call_map_map_bg" value="<?php echo esc_attr(get_option('call_map_map_bg', '#dc3545')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Map Button Text Color</th>
                    <td><input type="color" name="call_map_map_text" value="<?php echo esc_attr(get_option('call_map_map_text', '#ffffff')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Button Text Size (px)</th>
                    <td><input type="number" name="call_map_text_size" value="<?php echo esc_attr(get_option('call_map_text_size', '18')); ?>" min="10" max="50" /></td>
                </tr>
            </table>
            <?php submit_button('Save Changes'); ?>
        </form>
    </div>
    <?php
}

// Register settings and sanitization
function call_map_buttons_register_settings() {
    register_setting('call_map_buttons_group', 'call_map_phone', 'sanitize_phone');
    register_setting('call_map_buttons_group', 'call_map_address', 'sanitize_address');
    register_setting('call_map_buttons_group', 'call_map_call_label', 'sanitize_button_text');
    register_setting('call_map_buttons_group', 'call_map_map_label', 'sanitize_button_text');
    register_setting('call_map_buttons_group', 'call_map_call_bg', 'sanitize_hex_color');
    register_setting('call_map_buttons_group', 'call_map_call_text', 'sanitize_hex_color');
    register_setting('call_map_buttons_group', 'call_map_map_bg', 'sanitize_hex_color');
    register_setting('call_map_buttons_group', 'call_map_map_text', 'sanitize_hex_color');
    register_setting('call_map_buttons_group', 'call_map_text_size', 'absint');
}
add_action('admin_init', 'call_map_buttons_register_settings');

// Enqueue Dashicons on frontend
function enqueue_dashicons() {
    wp_enqueue_style('dashicons');
}
add_action('wp_enqueue_scripts', 'enqueue_dashicons');

// Display buttons on frontend
function display_call_map_buttons() {
    $phone = esc_attr(get_option('call_map_phone', '000000'));
    $phone_url = 'tel:' . $phone;
    $address = esc_url(get_option('call_map_address', 'https://www.google.com'));
    $call_label = esc_html(get_option('call_map_call_label', 'CALL'));
    $map_label = esc_html(get_option('call_map_map_label', 'MAP'));
    $call_bg = sanitize_hex_color(get_option('call_map_call_bg', '#28a745'));
    $call_text = sanitize_hex_color(get_option('call_map_call_text', '#ffffff'));
    $map_bg = sanitize_hex_color(get_option('call_map_map_bg', '#dc3545'));
    $map_text = sanitize_hex_color(get_option('call_map_map_text', '#ffffff'));
    $text_size = absint(get_option('call_map_text_size', 18));

    // Apply escaping functions to the styles and HTML
    $styles = sprintf(
        '<style>
            .mobile-bottom-bar {
                position: fixed;
                bottom: 0;
                width: 100%%;
                display: flex !important;
                background: #000 !important;
                z-index: 9999;
                padding: %spx !important;
                box-sizing: border-box;
                justify-content: center !important;
                gap: %spx !important;
            }
            .mobile-bottom-bar a {
                flex: 1 !important;
                text-align: center;
                padding: %spx %spx !important;
                font-size: %spx !important;
                font-weight: bold;
                color: %s !important;
                text-decoration: none;
                box-sizing: border-box;
                border-radius: %spx !important;
                margin: 0 !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                min-width: %spx !important;
                min-height: %spx !important;
            }
            .mobile-bottom-bar .call {
                background: %s !important;
            }
            .mobile-bottom-bar .map {
                background: %s !important;
            }
            .mobile-bottom-bar a .button-content {
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                width: 100%%;
            }
            .mobile-bottom-bar a .dashicons {
                font-size: %spx !important;
                margin-right: %spx !important;
                vertical-align: middle;
                line-height: %spx !important;
            }
            .mobile-bottom-bar .call .dashicons:before {
                color: %s !important;
            }
            .mobile-bottom-bar .map .dashicons:before {
                color: %s !important;
            }
            @media (min-width: 768px) {
                .mobile-bottom-bar {
                    display: none !important;
                }
            }
        </style>',
        esc_attr($text_size * 0.2),
        esc_attr($text_size * 0.6),
        esc_attr($text_size / 3), esc_attr($text_size * 0.8),
        esc_attr($text_size),
        esc_attr($call_text),
        esc_attr($text_size * 2),
        esc_attr($text_size * 4),
        esc_attr($text_size * 1.8),
        esc_attr($call_bg),
        esc_attr($map_bg),
        esc_attr($text_size * 1.5),
        esc_attr($text_size * 0.7),
        esc_attr($text_size),
        esc_attr($call_text),
        esc_attr($map_text)
    );

    // Build HTML with proper escaping
    $html = sprintf(
        '<div class="mobile-bottom-bar">
            <a class="call" href="%s">
                <span class="button-content"><span class="dashicons dashicons-phone"></span> %s</span>
            </a>
            <a class="map" href="%s">
                <span class="button-content"><span class="dashicons dashicons-location"></span> %s</span>
            </a>
        </div>',
        esc_url($phone_url),
        esc_html($call_label),
        esc_url($address),
        esc_html($map_label)
    );

    // Output the styles and HTML separately with escaping
    echo wp_kses($styles, ['style' => []]); // Escape inline styles
    echo wp_kses_post($html);  // Escape HTML output
}
add_action('wp_footer', 'display_call_map_buttons');

